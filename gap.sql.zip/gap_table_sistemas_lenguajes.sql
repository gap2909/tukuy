
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sistemas_lenguajes`
--

CREATE TABLE `sistemas_lenguajes` (
  `id` int(11) NOT NULL,
  `lenguaje` char(5) COLLATE utf8_spanish_ci NOT NULL,
  `lenguaje_desc` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sistemas_lenguajes`
--

INSERT INTO `sistemas_lenguajes` (`id`, `lenguaje`, `lenguaje_desc`) VALUES
(1, 'ES_es', 'Español latinoamericano'),
(2, 'US_us', 'Inglés Norteamericano');
