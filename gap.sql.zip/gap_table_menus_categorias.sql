
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus_categorias`
--

CREATE TABLE `menus_categorias` (
  `id` int(11) NOT NULL,
  `menu_categoria` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `menu_categoria_desc` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `menus_categorias`
--

INSERT INTO `menus_categorias` (`id`, `menu_categoria`, `menu_categoria_desc`) VALUES
(1, 'Navegación', 'Menú ubicado en la barra de navegación principal'),
(2, 'Usuario', 'Menú de navegación según el tipo de usuario');
