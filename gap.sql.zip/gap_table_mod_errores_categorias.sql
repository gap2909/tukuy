
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_errores_categorias`
--

CREATE TABLE `mod_errores_categorias` (
  `id_categoria_error` int(10) UNSIGNED NOT NULL,
  `categoria` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mod_errores_categorias`
--

INSERT INTO `mod_errores_categorias` (`id_categoria_error`, `categoria`, `descripcion`) VALUES
(1, 'Acceso', 'Errores que tienen que ver con el acceso al sistema'),
(2, 'Sistema', 'Errores que se pueden generar en el sistema');
