
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_errores`
--

CREATE TABLE `mod_errores` (
  `codigo` int(4) UNSIGNED NOT NULL,
  `categoria_error` tinyint(2) UNSIGNED NOT NULL,
  `error` text COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mod_errores`
--

INSERT INTO `mod_errores` (`codigo`, `categoria_error`, `error`) VALUES
(1000, 2, 'Ha ocurrido un error y la p&aacute;gina no puede mostrarse'),
(1010, 1, 'Acceso denegado');
