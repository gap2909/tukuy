
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `menus_categorias`
--
ALTER TABLE `menus_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `modulos_categorias`
--
ALTER TABLE `modulos_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mod_errores`
--
ALTER TABLE `mod_errores`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `mod_errores_categorias`
--
ALTER TABLE `mod_errores_categorias`
  ADD PRIMARY KEY (`id_categoria_error`);

--
-- Indices de la tabla `mod_noticias`
--
ALTER TABLE `mod_noticias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mod_noticias_categorias`
--
ALTER TABLE `mod_noticias_categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mod_usuarios`
--
ALTER TABLE `mod_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mod_usuarios_grupos`
--
ALTER TABLE `mod_usuarios_grupos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mod_usuarios_roles`
--
ALTER TABLE `mod_usuarios_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `sistemas`
--
ALTER TABLE `sistemas`
  ADD PRIMARY KEY (`sitio`);

--
-- Indices de la tabla `sistemas_lenguajes`
--
ALTER TABLE `sistemas_lenguajes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `menus_categorias`
--
ALTER TABLE `menus_categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `modulos`
--
ALTER TABLE `modulos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `modulos_categorias`
--
ALTER TABLE `modulos_categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `mod_errores_categorias`
--
ALTER TABLE `mod_errores_categorias`
  MODIFY `id_categoria_error` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `mod_noticias`
--
ALTER TABLE `mod_noticias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `mod_noticias_categorias`
--
ALTER TABLE `mod_noticias_categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `mod_usuarios`
--
ALTER TABLE `mod_usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT de la tabla `mod_usuarios_roles`
--
ALTER TABLE `mod_usuarios_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT de la tabla `sistemas_lenguajes`
--
ALTER TABLE `sistemas_lenguajes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;