
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos_categorias`
--

CREATE TABLE `modulos_categorias` (
  `id` int(11) NOT NULL,
  `modulo_categoria` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `modulo_desc_categoria` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `modulos_categorias`
--

INSERT INTO `modulos_categorias` (`id`, `modulo_categoria`, `modulo_desc_categoria`) VALUES
(1, 'Módulo de Usuarios', 'Categoría que permite agrupar los módulos que gestionan los usuarios, grupos y accesos.'),
(2, 'Módulo del Sistema', 'Agrupa todos los módulos que gestionan al sistema'),
(3, 'Módulo de Errores', 'Modelo encargado de los errores'),
(4, 'Módulo de Noticias', 'Módulo que contiene las noticias');
