
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_usuarios_grupos`
--

CREATE TABLE `mod_usuarios_grupos` (
  `id` int(11) NOT NULL,
  `usuario_grupo` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_grupo_desc` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
