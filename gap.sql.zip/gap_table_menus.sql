
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `id_categoria` tinyint(4) NOT NULL,
  `menu_titulo` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `menu_url` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `menu_desc` varchar(100) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `menus`
--

INSERT INTO `menus` (`id`, `id_categoria`, `menu_titulo`, `menu_url`, `visible`, `menu_desc`) VALUES
(1, 1, 'Inicio', 'index', 1, 'Dirige a la página principal del sitio'),
(2, 1, 'Acerca de', 'about', 1, 'Dirige a la pagina a cerca de los autores del sitio'),
(3, 1, 'Contáctenos', 'contacto', 1, 'Dirige al formulario de contacto'),
(4, 1, 'Políticas', 'politicas', 0, 'Dirige a la página de políticas de privacidad de datos en el sitio'),
(5, 1, 'Preguntas Frecuentes', 'preguntas', 0, 'Dirige a la página de preguntas Frecuentes de los usuario'),
(6, 1, 'Foro', 'foro', 0, 'Dirige al foro del sitio'),
(7, 2, 'Perfil', 'perfil', 0, 'Página de configuración del perfil del usuario');
