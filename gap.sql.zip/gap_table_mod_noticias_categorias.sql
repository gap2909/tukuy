
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_noticias_categorias`
--

CREATE TABLE `mod_noticias_categorias` (
  `id` int(11) NOT NULL,
  `noticia_categoria` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` text COLLATE utf8_spanish_ci NOT NULL,
  `creado` datetime NOT NULL,
  `modificado` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
