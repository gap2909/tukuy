
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_usuarios`
--

CREATE TABLE `mod_usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `f_nacimiento` date NOT NULL,
  `genero` tinyint(4) NOT NULL,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `clave` char(40) COLLATE utf8_spanish_ci NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `id_role` tinyint(4) NOT NULL,
  `codigo` int(10) NOT NULL,
  `creado` datetime NOT NULL,
  `modificado` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mod_usuarios`
--

INSERT INTO `mod_usuarios` (`id`, `usuario`, `nombres`, `apellidos`, `f_nacimiento`, `genero`, `email`, `clave`, `estado`, `id_role`, `codigo`, `creado`, `modificado`) VALUES
(1, 'admin', 'Gustavo', 'Paez', '1972-09-18', 1, 'admin@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 1, 1, 0, '2018-03-18 15:15:00', '2018-06-23 01:21:37'),
(2, 'gap2909', 'Gustavo', 'Paez', '1972-09-18', 1, 'gap2909@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 1, 4, 0, '2018-06-20 16:35:57', '2018-06-20 16:35:57'),
(3, 'gpaez', 'Gustavo', 'Paez', '1972-09-18', 1, 'gpaez@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1295124274, '2018-06-20 17:17:47', '2018-06-20 17:17:47'),
(4, 'usuario1', 'Gustavo', 'Paez', '2018-06-20', 1, 'usuario1@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1247559841, '2018-06-20 17:28:38', '2018-06-20 17:28:38'),
(5, 'usuario2', 'Gustavo', 'Paez', '2018-06-20', 1, 'usuario2@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1258111776, '2018-06-20 17:30:37', '2018-06-20 17:30:37'),
(6, 'usuario3', 'Gustavo', 'Paez', '2018-06-20', 1, 'usuario3@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1367961457, '2018-06-20 17:39:25', '2018-06-20 17:39:25'),
(7, 'usuario4', 'Gustavo', 'Paez', '2018-06-20', 1, 'usuario4@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1326710886, '2018-06-20 17:42:14', '2018-06-20 17:42:14'),
(8, 'usuario5', 'Gustavo', 'Paez', '2018-06-20', 1, 'usuario5@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1261017883, '2018-06-20 18:05:56', '2018-06-20 18:05:56'),
(9, 'usuario6', 'Ambita', 'Paez Campos', '2010-04-23', 2, 'apaez@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 1, 4, 1374373343, '2018-06-20 18:13:29', '2018-06-21 11:14:47'),
(10, 'usuario7', 'Arturo', 'Paez', '2018-06-21', 1, 'usuario7@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 0, 4, 1272371304, '2018-06-20 18:41:14', '2018-06-20 18:41:14'),
(43, 'usuario8', 'Guerrero', 'Comando', '2018-06-01', 2, 'usuario8@eval.org.ve', 'dce7ab2912bcf8a8d48681540545cba269ba54fc', 1, 4, 1229108370, '2018-06-24 16:52:40', '2018-06-24 16:54:41');
