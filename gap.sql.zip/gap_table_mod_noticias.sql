
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_noticias`
--

CREATE TABLE `mod_noticias` (
  `id` int(11) NOT NULL,
  `titulo` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `cuerpo` longtext COLLATE utf8_spanish_ci NOT NULL,
  `palabras_claves` text COLLATE utf8_spanish_ci NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_autor` int(11) NOT NULL,
  `creado` datetime NOT NULL,
  `modificado` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mod_noticias`
--

INSERT INTO `mod_noticias` (`id`, `titulo`, `cuerpo`, `palabras_claves`, `id_categoria`, `id_autor`, `creado`, `modificado`) VALUES
(1, 'Tema 1', 'Ni siquiera los todopoderosos signos de puntuación dominan a los textos simulados; una vida, se puede decir, poco ortográfica.\r\n\r\nPero un buen día, una pequeña línea de texto simulado, llamada Lorem Ipsum, decidió aventurarse y salir al vasto mundo de la gramática.\r\n\r\nEl gran Oxmox le desanconsejó hacerlo, ya que esas tierras estaban llenas de comas malvadas, signos de interrogación salvajes y puntos y coma traicioneros, pero el texto simulado no se dejó atemorizar. Empacó sus siete versales, enfundó su inicial en el cinturón y se puso en camino. Cuando ya había escalado las primeras colinas de las montañas cursivas, se dio media vuelta para dirigir su mirada por última vez, hacia su ciudad natal Letralandia, el encabezamiento del pueblo Alfabeto', 'tema1, tema2, tema3, tema4', 1, 1, '2018-10-08 21:00:00', '2018-10-09 07:35:00'),
(2, 'Tema 2', 'Muy lejos, más allá de las montañas de palabras, alejados de los países de las vocales y las consonantes, viven los textos simulados. Viven aislados en casas de letras, en la costa de la semántica, un gran océano de lenguas.\r\n\r\nUn riachuelo llamado Pons fluye por su pueblo y los abastece con las normas necesarias. Hablamos de un país paraisomático ', 'tema01, tema02, tema03, tema04', 1, 1, '2018-10-09 07:30:00', '2018-10-09 07:30:00');
