
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sistemas`
--

CREATE TABLE `sistemas` (
  `sitio` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `slogan` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `empresa` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `year` char(4) COLLATE utf8_spanish_ci NOT NULL,
  `id_lenguaje` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `sistemas`
--

INSERT INTO `sistemas` (`sitio`, `slogan`, `empresa`, `year`, `id_lenguaje`) VALUES
('EVAL', 'Sitio Oficial', 'Fundación EVAL', '2018', 1);
