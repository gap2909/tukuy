
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `id` int(11) NOT NULL,
  `id_categoria_modulo` tinyint(4) NOT NULL,
  `modulo_nombre` varchar(200) COLLATE utf8_spanish_ci NOT NULL,
  `modulo_desc` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `modulo_directorio` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `modulos`
--

INSERT INTO `modulos` (`id`, `id_categoria_modulo`, `modulo_nombre`, `modulo_desc`, `modulo_directorio`) VALUES
(1, 2, 'Módulo Sistema', 'Módulo que se encarga de parámetros del sistema', 'sistemas'),
(2, 1, 'Módulo Usuarios', 'Módulo de trabajo con usuarios', 'usuarios'),
(3, 3, 'Módulo Errores', 'Modulo que gestiona los errores', 'errores'),
(4, 4, 'Módulo Noticias', 'Módulos de noticias', 'noticias');
