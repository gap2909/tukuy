
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mod_usuarios_roles`
--

CREATE TABLE `mod_usuarios_roles` (
  `id` int(11) NOT NULL,
  `usuario_role` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `usuario_role_desc` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `mod_usuarios_roles`
--

INSERT INTO `mod_usuarios_roles` (`id`, `usuario_role`, `usuario_role_desc`) VALUES
(1, 'Administrador', 'Tiene control total del sistema'),
(2, 'Diseñador', 'Tiene acceso y control sobre el diseño de temas del sistema'),
(3, 'Editor', 'Tiene la posibilidad de crear contenido en el sistema'),
(4, 'Usuario', 'Tiene acceso básico del sistema'),
(5, 'Invitado', 'Tiene acceso solo a información básica y de solicitar registro en el sistema');
